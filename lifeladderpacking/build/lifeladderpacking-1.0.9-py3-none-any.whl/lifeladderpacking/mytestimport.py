def printTest(): 
    print(12345)