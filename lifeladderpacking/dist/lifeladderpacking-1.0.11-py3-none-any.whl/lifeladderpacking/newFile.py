def newFunc():
    print('I am new :-)')
    return "Juhuuuu"