"""
class Item:
    
    # initialize an item
    def __init__(self, weight, addedHeightToPallet):
        self.weight = weight
        self.height = addedHeightToPallet
"""